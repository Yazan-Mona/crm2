@extends('layouts.admin')
@section('content')
<link rel="stylesheet" href="assets/css/bootstrap.css">
 <!-- <link rel="stylesheet" href="assets/vendors/jquery-datatables/jquery.dataTables.min.css"> -->
<link rel="stylesheet" href="assets/vendors/jquery-datatables/jquery.dataTables.bootstrap5.min.css">


    <!-- Basic Tables start -->
    <section class="section">
        <div class="card">
            <div class="card-header">
            <button type="button" class="btn btn-primary">Add New</button>
            <button type="button" class="btn btn-primary  bi-eye"></button>
            <span class="float-right">
                    <a class="btn btn-primary" href="{{ route('owners.create') }}">New Owner</a>
                </span>
            </div>
        
           
            <div class="card-body">
                <table class="table   table-bordered  " id="table1">
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>

                            <th>Email</th>
                            <th>nationality</th>
                            <th>source</th>
                            <th>emirate_id</th>
                            <th>assign_to</th>
                            <th>mobile</th>
                            <th>alternate_mobile</th>
                            <th>Status</th>
                            <th width="280px">Action</th> 
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($data as $key => $owner)
                    <tr>
                    <td>
                            {{ $owner->firstname ?? '' }}
                        </td>
                        <td>
                            {{ $owner->lastname ?? '' }}
                        </td>
                        <td>
                            {{ $owner->email ?? '' }}
                        </td>
                        <td>
                            {{  $owner->nationality ?? '' }}
                        </td>
                        <td>
                            {{ $owner->source ?? '' }}
                        </td>
                        <td>
                            {{ $owner->emirate_id_number ?? '' }}
                        </td>
                        <td>
                            {{ $owner->user_id ?? '' }}
                        </td>
                        <td>
                            {{ $owner->mobile ?? '' }}
                        </td>
                        <td>
                            {{ $owner->alternate_mobile ?? '' }}
                        </td>
                        <td>
                                <span class="badge bg-success">Active</span>
                        </td>
                        <td>
                        <a class="btn btn-primary  bi-eye" href="{{ route('owners.show', $owner->id) }}"></a>

                        <a  class="btn btn-info   bi-pencil-square"  href="{{ route('owners.edit', $owner->id) }}"></a>
                        <a class="btn btn-success  bi-chat-dots"></a>
              
                        <form action="{{ route('owners.destroy', $owner->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                               
                                <button type="submit" class="btn btn-danger  bi-trash">
                                 
                                </button>
                            </form>
                    
                          
                                </td>
                    </tr>   
                    @endforeach
                      

                    </tbody>
                </table>
            </div>
        </div>

    </section>
    <!-- Basic Tables end -->
    
    <script src="assets/vendors/jquery/jquery.min.js"></script>
<script src="assets/vendors/jquery-datatables/jquery.dataTables.min.js"></script>
<script src="assets/vendors/jquery-datatables/custom.jquery.dataTables.bootstrap5.min.js"></script>
<script src="assets/vendors/fontawesome/all.min.js"></script>
<script>
    // Jquery Datatable
    let jquery_datatable = $("#table1").DataTable()
</script>


@endsection
